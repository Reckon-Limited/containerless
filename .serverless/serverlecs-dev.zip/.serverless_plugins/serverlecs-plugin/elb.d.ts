export declare class ELB {
    service: any;
    constructor(service: any);
    readonly name: string;
    readonly elbRoleName: string;
    generateResources(): {};
}
