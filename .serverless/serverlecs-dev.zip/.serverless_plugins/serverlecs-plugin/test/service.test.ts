import { suite, test, slow, timeout, skip, only } from "mocha-typescript";

import { expect } from 'chai';

import { Service } from '../service'

import * as _ from 'lodash';

const opts = {
  name:       'Blah',
  repository: 'blah/vtha',
  clusterId:  'arn:blah:vtha',
  port: 3000,
  load_balancer: {
    vpcId: 'vpc-123456',
    security_group: 'sg-123456',
    subnets: ['subnet-123456']
  }
}

@suite
class ServiceTest {

  resources: any;

  before() {
    let service = new Service(opts);
    this.resources = service.generateResources();
  }

  @test('Service Resource')
  assert_service_resource() {
    let result = _.get(this.resources, 'Blah.Type');
    expect(result).to.eq('AWS::ECS::Service')

    result = _.get(this.resources, 'Blah.Properties.Cluster');
    expect(result).to.eq(opts.clusterId)
  }

  @test('Container Resource')
  assert_container_resource() {
    let result = _.get(this.resources, 'BlahTaskDefinition.Type');
    expect(result).to.eq('AWS::ECS::TaskDefinition')

    result = _.get(this.resources, 'BlahTaskDefinition.Properties.ContainerDefinitions[0].Name');
    expect(result).to.eq('Blah')
  }

  @test('ELB Resource')
  assert_elb_resource() {
    let result = _.get(this.resources, 'ContainerlessELB.Type');
    expect(result).to.eq('AWS::ElasticLoadBalancingV2::LoadBalancer')
  }
}
